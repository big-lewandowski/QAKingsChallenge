﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonarchsChallengeTests
{
    public class TestData
    {
        public int expectedAmountOfMonarchs = 57;
        public int expectedLongestRulingMonarchResult = 73;
        public string expectedLongestRulingMonarch = "Elizabeth II";
        public string expectedLongestRulingMonarchHouse = "House of Windsor";
        public string expectedMostLongestRulingMonarchHouse = "House of Hanover";
        public string expectedMostCommonMonarchName = "Edward";
    }
}
