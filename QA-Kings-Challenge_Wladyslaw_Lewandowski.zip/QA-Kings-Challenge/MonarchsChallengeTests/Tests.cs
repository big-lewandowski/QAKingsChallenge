﻿using MonarchsChallenge;
using System.Runtime.CompilerServices;

namespace MonarchsChallengeTests
{
    [TestFixture]
    public class Tests : Program
    {

        TestData TestData = new TestData();
        AppData AppData = new AppData();
       
        [OneTimeSetUp]
        public async Task SetUp()
        {
            AppData.customHttpClientTest = new CustomClient();
            AppData.collector = new MonarchsCollector(AppData.customHttpClientTest);
            AppData.monarchs = await AppData.collector.GetMonarchs();
        }

        [Test]
        public async Task TestIfAmountOfMonarchsIsCorrect()
        {
            AppData.actualAmountOfMonarchs = AppData.monarchs.CountMonarchs();
            Assert.That(AppData.actualAmountOfMonarchs.Equals(TestData.expectedAmountOfMonarchs));
            Console.WriteLine(@$"Actual list of monarchs is correct, checked value: {AppData.actualAmountOfMonarchs}, expected value: {TestData.expectedAmountOfMonarchs}");
        }

        [Test]
        public async Task TestLongestRullingMonarchName()
        {
            AppData.actualLongestRulingMonarch = AppData.monarchs.LongestRulingMonarch();
            Assert.That(AppData.actualLongestRulingMonarch.Name.Equals(TestData.expectedLongestRulingMonarch));
            Console.WriteLine($@"Expected longest ruling monarch name:{TestData.expectedLongestRulingMonarch}, test result: {AppData.actualAmountOfMonarchs}. Test passed.");
        }

        [Test]
        public async Task TestLongestRullingMonarchResult()
        {
            AppData.actualLongestRulingMonarch = AppData.monarchs.LongestRulingMonarch();
            Assert.That(AppData.actualLongestRulingMonarch.RulingLength, Is.EqualTo(TestData.expectedLongestRulingMonarchResult));
            Console.WriteLine($@"Expected value:{TestData.expectedLongestRulingMonarchResult}, actual value: {AppData.actualLongestRulingMonarch.RulingLength}. Test passed.");
        }

        [Test]
        public async Task TestLongestRullingMonarchHouse()
        {
            AppData.actualLongestRulingMonarch = AppData.monarchs.LongestRulingMonarch();
            Assert.That(AppData.actualLongestRulingMonarch.House, Is.EqualTo(TestData.expectedLongestRulingMonarchHouse));
            Console.WriteLine($@"Expected value:{TestData.expectedLongestRulingMonarchHouse}, actual value: {AppData.actualLongestRulingMonarch.House}. Test passed.");
        }

        [Test]
        public async Task TestMostLongestRullingMonarchHouse()
        {
            AppData.actualLongestRulingHouse = AppData.monarchs.LongestRulingHouse();
            Assert.That(AppData.actualLongestRulingHouse.HouseName, Is.EqualTo(TestData.expectedMostLongestRulingMonarchHouse));
            Console.WriteLine($@"Expected value:{TestData.expectedMostLongestRulingMonarchHouse}, actual value: {AppData.actualLongestRulingHouse.HouseName}. Test passed.");
        }

        [Test]
        public async Task TestTheMostCommonMonarchName()
        {
            AppData.actualMostCommonMonarchName = AppData.monarchs.MostCommonMonarchName();
            Assert.That(AppData.actualMostCommonMonarchName, Is.EqualTo(TestData.expectedMostCommonMonarchName));
            Console.WriteLine($@"Expected value:{TestData.expectedMostCommonMonarchName}, actual value: {AppData.actualMostCommonMonarchName}. Test passed.");
        }

    }
}

