﻿using MonarchsChallenge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonarchsChallengeTests
{
    public class AppData
    {
        public CustomClient customHttpClientTest;
        public MonarchsCollector collector;
        public Monarch[] monarchs;
        public int actualAmountOfMonarchs;
        public MonarchHouse actualLongestRulingHouse;
        public Monarch actualLongestRulingMonarch;
        public string actualMostCommonMonarchName;

    }
}
