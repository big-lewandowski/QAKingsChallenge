namespace MonarchsChallenge;

public interface IHttpClient
{
    public Task<HttpResponseMessage> GetAsync(string url);
}

public class CustomClient : IHttpClient
{
    public static readonly HttpClient _httpClient = new HttpClient();

    public Task<HttpResponseMessage> GetAsync(string url) => _httpClient.GetAsync(url);
}